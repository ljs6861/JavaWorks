package com.main;

import com.login.LoginGUI;

public class Main {

	public static void main(String[] args) {

		LoginGUI loginGui = new LoginGUI();
		
	}
	

}

package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.main.HomeGUI;

public abstract class LoginDAO {
	private static DefaultTableModel model;
	static PreparedStatement pSt ;
	LoginGUI login = new LoginGUI();

	// 애완견 관리기능 클래스
	// ------------------------------------------------------------
	public static void LoginInsert(String str1, String str2, String str3, String str4) { // DB에
		// 애완견 저장하는
		// 메소드

		Connection conn = null;
		Statement stmt = null;
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "!BitCom0228");
			stmt = conn.createStatement();

			String queryLang = "insert into logintbl (ID, 비밀번호, 이름, 전화번호) values('" + str1 + "', '" + str2 + "', '"
					+ str3 + "', '" + str4 + "');";
			stmt.executeUpdate(queryLang);
			System.out.println("새로운 회원 등록완료.");

	

			
			
		} catch (ClassNotFoundException cnfe) {
			System.out.println("해당 클래스를 찾을 수 없습니다." + cnfe.getMessage());
		} catch (SQLException se) {
			System.out.println(se.getMessage());
		} finally {
			try {
				stmt.close();
			} catch (Exception a) {
			}
			try {
				conn.close();
			} catch (Exception a) {
			}
		}
	}

	// ------------------------------------------------------------
	public static int LoginSearch(String ID, String 비밀번호) { // 애완견
															// 검색기능
															// 메소드

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		String dbpasswd = "";
		int x = -1;

		try {
			Class.forName("org.gjt.mm.mysql.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "!BitCom0228");
			sql = "select 비밀번호 from logintbl where ID = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ID);
			rs = pstmt.executeQuery();

			if (rs.next()) {

				dbpasswd = rs.getString("비밀번호");
				if (dbpasswd.equals(비밀번호)) {
					x = 1; // 인증성공
					HomeGUI homeGui = new HomeGUI();
					
					JOptionPane.showMessageDialog(null, "펫월드에 오신걸 환영합니다!");
				} 
				else {

					x = 0; // 비밀번호 틀림
					LoginGUI loginGui = new LoginGUI();
					JOptionPane.showMessageDialog(null, "비밀번호가 틀렸습니다.");
				}

			} 
			
			else {
				x = -1; // 해당 아이디 없음
				LoginGUI loginGui = new LoginGUI();
				JOptionPane.showMessageDialog(null, "해당 아이디가 없습니다.");
			} 
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			execClose(rs, pstmt, conn);
		}
		return x;
	}

	

	private static void execClose(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		// TODO Auto-generated method stub

	}

	

	public static void printTable(JTable table) {
		// TODO Auto-generated method stub

	}

}


--drop table logintbl; 
create database login;

use login;

create table logintbl(
ID varchar(30) NOT NULL, 
비밀번호 varchar(30)NOT NULL,
이름 varchar(50)NOT NULL,
전화번호 varchar(30) NOT NULL,

PRIMARY KEY(ID)
);


insert into logintbl values('ljs6861','123123','이지성','010-7242-6861');

select * from logintbl;


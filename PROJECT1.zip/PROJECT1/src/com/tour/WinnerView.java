package com.tour;

import java.awt.Container;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.dog.DogGUI;
import com.main.HomeGUI;


public class WinnerView extends JFrame{
	

						private static final LayoutManager FlowLayout = null;
	private String winDog;
	
	public WinnerView(){
		
	}
	
						//우승개 이미지이름
	public WinnerView(String winner){
		
		winDog = winner;
		
		JFrame frame = new JFrame("애완견 이상형 월드컵");
		frame.setLocation(250, 200);

		Container contentPane = frame.getContentPane();
		
		JPanel panel = new JPanel();
		
		Img imgWinner = new Img(winner, "", 615, 80, 400, 400);
		imgWinner.draw(panel);
							//우승패널 배경이미지
		Img img = new Img("Winner.png", "", 0, 0, 1100, 600);
		img.draw(panel);

		
		
	
		
		panel.setLocation(250, 200);
		panel.setBounds(0, 0, 1300, 550);
		panel.setLayout(FlowLayout);
	
		
		JButton button = new JButton("뒤로 가기");
		button.setBounds(940, 20, 100, 40);
		panel.add(button);
		
		JButton button2 = new JButton("우승견 정보");
		button2.setBounds(800, 20, 130, 40);
		panel.add(button2);
		
		
		contentPane.add(panel);
		
		
		ActionListener obj1 = new ActionListener()  {
			public void actionPerformed (ActionEvent e)  {
				
				HomeGUI home = new HomeGUI();
		
				frame.setVisible(false);
			}
		};
		button.addActionListener(obj1);
		
		
		//DogGui
		//  + 검색 (품종) Textfiled에 우승자명 자동 삽입 
		ActionListener obj2 = new ActionListener()  {
			public void actionPerformed (ActionEvent e)  {
				
				DogGUI dog = new DogGUI();
				
		
				frame.setVisible(false);
			}
		};
		button2.addActionListener(obj2);
		
		

	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1100,600);
		frame.setVisible(true);
		
	}
	
//	class viewInfo implements ActionListener{
//
//		@Override
//		public void actionPerformed(ActionEvent e) {
//
//			DogGui dog = new DogGui();
//			
//		}
//
//	
//	}
	
	
	
	
	public String getWinDog() {
		return winDog;
	}
	
	
}

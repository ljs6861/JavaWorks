--drop table Shoptbl;  
create database Shop;

use Shop;

create table Shoptbl(
애견샵 varchar(30) primary key,
지역 varchar(30),
주소 varchar(50),
연락처 varchar(30),
사이트 varchar(50)

);




insert into Shoptbl values('펫월드','남구','광주광역시 남구 주월동 1283-1','062-676-9319','http://petworldjw.itrocks.kr');
insert into Shoptbl values('펫마트','서구','광주광역시 서구 쌍촌동 266-1', '062-374-9799','http://ssangchonpetmart.modoo.at');
insert into Shoptbl values('애견본가' ,'북구','광주광역시 북구 두암동 907-12',  '062-512-7005',  'http://kjdog.co.kr');
insert into Shoptbl values('똥강아지','광산구',  '광주광역시 광산구 신가동1047-5','062-959-5672',  'http://blog.naver.com/ygoxid1');
insert into Shoptbl values('앙증맞개','광산구',  '광주광역시 광산구 신창동 1209-5','062-952-4556', 'http://앙증맞개.com');
insert into Shoptbl values('UDOG' ,'광산구','광주광역시 광산구 장덕동 1601',   '010-9318-6840', 'http://blog.naver.com/hxppy0486');
insert into Shoptbl values('도도하개','서구', '광주광역시 서구 치평동 1320-5 3층',  '070-8860-1631',  'http://blog.naver.com/pethotel_dodo' );
insert into Shoptbl values('펫홀릭' ,'서구','광주광역시 서구 마륵동 171-38', '070-7723-8274', 'http://petholic.co.kr');
insert into Shoptbl values('Stay','서구', '광주광역시 서구 쌍촌동 1278-7',  '010-9647-5999',  'http://blog.naver.com/stay911' );
insert into Shoptbl values('하트강아지' ,'서구','광주광역시 서구 동천동 615 ', '062-523-3880',  'http://blog.naver.com/ay1250');
insert into Shoptbl values('꼬리치는강아지','남구', '광주광역시 남구 방림동 350-2 ', '062-655-6222',  'http://taildog.alltheway.kr');
insert into Shoptbl values('펫챔' ,'북구','광주광역시 북구 운암동 153-37'  ,'062-526-6566' ,'http://petcham.com');
insert into Shoptbl values('애견11번가' ,'동구','광주광역시 동구 호남동 48-1',   '050-4309-1478', 'http://05043091478.modoo.at');
insert into Shoptbl values('개밥도둑','서구', '광주광역시 서구 쌍촌동 1345-12',  '010-7600-1933', 'http://instagram.com/kong320');
insert into Shoptbl values('왈가독',  '서구', '광주광역시 서구 풍암동 1093', '070-4221-0722',  'http://walgadog.co.kr');
insert into Shoptbl values('스누피' , '서구','광주광역시 서구 화정동 779-5 2층' , '062-351-0565' , 'http://blog.naver.com/ddvkdd' );
insert into Shoptbl values('밀크네','광산구', '광주광역시 광산구 첨단2동 830-6',  '010-4194-6516', 'http://blog.naver.com/milknecoffee');
insert into Shoptbl values('맥도그날드' ,'서구','광주광역시 서구 풍암동 1157-15', '010-5668-5661',  'http://macdognald.co.kr');
insert into Shoptbl values('견선생','서구', '광주광역시 서구 풍암동 993-1 1층', '062-672-1259', 'http://견선생.com');
insert into Shoptbl values('애견천국' ,'북구', '광주광역시 북구 오치동 866-2 ' , '062-268-1226' ,'http://dog1009.co.kr');
insert into Shoptbl values('패션독' ,'서구','광주광역시 서구 농성동 656-51','010-9696-8484',  'http://fashiondog.kr');
insert into Shoptbl values('멍스토어' ,'서구', '광주광역시 서구 화정동 74-7 제이지파크 1층',  '062-366-3939', 'http://mungstore.com');
insert into Shoptbl values('문캐터리','서구', '광주광역시 서구 화정동 95-6', '010-7124-7193',  'http://blog.naver.com/lktykr1225' );
insert into Shoptbl values('펫왕국' ,'서구','광주광역시 서구 쌍촌동 1301-2', '062-383-8500' ,'http://petkingdom.alltheway.kr');
insert into Shoptbl values('하나로펫','광산구',  '광주광역시 광산구 신가동 1052', '010-3658-9709',   'http://blog.naver.com/gojaro');
insert into Shoptbl values('베이비독','광산구', '광주광역시 광산구 신창동 1236-7' , '062-959-0356'   ,'http://blog.naver.com/dy9222' );
insert into Shoptbl values('견우애견','서구', '광주광역시 서구 쌍촌동 1243-15',  '062-384-8648', 'http://blog.naver.com/gadomoim' );
insert into Shoptbl values('펫스토리' ,'광산구', '광주광역시 광산구 장덕동 1268' , '062-955-0279' , 'http://펫스토리.kr');
insert into Shoptbl values('개맑음','서구','광주광역시 서구 쌍촌동 1272-3 1층', '010-4618-5008', 'http://dogmalguem.modoo.at');
insert into Shoptbl values('애견마을' ,'북구', '광주광역시 북구 매곡동 33-14' , '062-573-2383' , 'http://j5759232.blog.me');
insert into Shoptbl values('노블레스독', '서구','광주광역시 서구 화정동 767-37', '010-5019-5505',   'http://cafe.naver.com/tawoolove' );
insert into Shoptbl values('카카오독' ,'남구','광주광역시 남구 구동 55-12','010-7907-7400', 'http://cafe.naver.com/tawoolove');
insert into Shoptbl values('멍블리','서구', '광주광역시 서구 화정동 766-62 1층', '062-365-3555', 'http://blog.naver.com/mung-vely' );
insert into Shoptbl values('알로하펫','서구', '광주광역시 서구 화정동 766-59' ,  '062-351-6997'  ,'http://blog.naver.com/alohapet');



select * from Shoptbl;
